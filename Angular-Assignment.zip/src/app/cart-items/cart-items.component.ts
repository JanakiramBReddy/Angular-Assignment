import { Component, OnInit } from '@angular/core';
// import  { ClientService }  from "../modules/client.service"

@Component({
  selector: 'app-cart-items',
  templateUrl: './cart-items.component.html',
  styleUrls: ['./cart-items.component.css']
})
export class CartItemsComponent implements OnInit {
  cartItemResponseData
  count = 0;
  constructor() { }

  ngOnInit(): void {

    this.cartItemResponseData = [{
      id: 1,
      name : "item 1",
      price : "175",
      discount : "5% off",
      img_url : "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSIMCi0h3phSUMntggEOOskGzmFmJc1Gc5f3kEngrGAoJCY8o24&usqp=CAU"
    },
    {
      id: 2,
      name : "item 2",
      price : "190",
      discount : "5% off",
      img_url : "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSIMCi0h3phSUMntggEOOskGzmFmJc1Gc5f3kEngrGAoJCY8o24&usqp=CAU"
    },
    {
      id: 3,
      name : "item 3",
      price : "213",
      discount : "20% off",
      img_url : "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSIMCi0h3phSUMntggEOOskGzmFmJc1Gc5f3kEngrGAoJCY8o24&usqp=CAU"
    },
    {
      id: 4,
      name : "item 4",
      price : "217",
      discount : "18% off",
      img_url : "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSIMCi0h3phSUMntggEOOskGzmFmJc1Gc5f3kEngrGAoJCY8o24&usqp=CAU"
    },
    {
      id: 5,
      name : "item 5",
      price : "319",
      discount : "31% off",
      img_url : "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSIMCi0h3phSUMntggEOOskGzmFmJc1Gc5f3kEngrGAoJCY8o24&usqp=CAU"
    }]
}
public cartCount(){
  this.count += 1;
}

}
