import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CartItemsComponent } from "./cart-items/cart-items.component";

const routes: Routes = [
  {
    path: "",
    redirectTo: "/cartItem",
    pathMatch: "full",
  },
  {
    path: "cartItem",
    component: CartItemsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponents = [
  CartItemsComponent
];
