export const environment = {
  production: true
};

export const ENV ={
  HOST : 'http://localhost:4000',
}
